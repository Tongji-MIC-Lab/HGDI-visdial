from visdialch.data.dataset import VisDialDataset
from visdialch.data.vocabulary import Vocabulary